@echo off
cd /d "%~dp0"
start "" luciole.exe window
